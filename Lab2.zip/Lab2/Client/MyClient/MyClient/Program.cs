﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.IO;
namespace CSCS1
{
    class SendProgram
    {
        static void Main(string[] args)
        {
            SendMessage();
        }
        private static void SendMessage()
        {

            string remoteAddress = "127.0.0.1";
            int port = 1001;
            Commands commands = new Commands();
            UdpClient sender = new UdpClient(0);
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(remoteAddress),
            port);
            Int16 x0, y0;
            Int16 x1, y1;
            Int16 radius;
            string text;
            string hexcolor;
            try
            {
                while (true)
                {
                    Console.Write("Введите команду > ");
                    string commandText = Console.ReadLine();
                    byte[] commandbyte = new byte[1];
                    byte[] result = new byte[1] { 0 };
                    switch (commandText)
                    {
                        case "1"://clear display
                            commandbyte[0] = 1;
                            hexcolor = ReadHexColor();
                            result = commands.ClearDisplayEncode(commandbyte[0], hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "2"://draw pixel
                            commandbyte[0] = 2;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            hexcolor = ReadHexColor();
                            result = commands.PixelEncode(commandbyte[0], x0, y0, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "3"://draw line
                            commandbyte[0] = 3;
                            x0 = ReadNumber("x0", false);
                            y0 = ReadNumber("y0", false);
                            x1 = ReadNumber("x1", false);
                            y1 = ReadNumber("y1", false);
                            hexcolor = ReadHexColor();
                            result = commands.FourNumbersEncode(commandbyte[0], x0, y0, x1, y1, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "4"://draw rectangle
                            commandbyte[0] = 4; x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Ширина", true);
                            y1 = ReadNumber("Высота", true);
                            hexcolor = ReadHexColor();
                            result = commands.FourNumbersEncode(commandbyte[0], x0, y0, x1, y1, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "5"://fill rectangle
                            commandbyte[0] = 5;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Ширина", true);
                            y1 = ReadNumber("Высота", true);
                            hexcolor = ReadHexColor();
                            result = commands.FourNumbersEncode(commandbyte[0],
                            x0, y0, x1, y1, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "6"://draw ellipse
                            commandbyte[0] = 6;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Радиус x", true);
                            y1 = ReadNumber("Радиус y", true);
                            hexcolor = ReadHexColor();
                            result = commands.FourNumbersEncode(commandbyte[0], x0, y0, x1, y1, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "7"://fill ellipse
                            commandbyte[0] = 7;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Радиус x", true);
                            y1 = ReadNumber("Радиус y", true);
                            hexcolor = ReadHexColor();
                            result = commands.FourNumbersEncode(commandbyte[0], x0, y0, x1, y1, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "8"://draw circle
                            commandbyte[0] = 8;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            radius = ReadNumber("Радиус", true);
                            hexcolor = ReadHexColor();
                            result = commands.CircleEncode(commandbyte[0], x0, y0, radius, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "9"://fill circle
                            commandbyte[0] = 9;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            radius = ReadNumber("Радиус", true);
                            hexcolor = ReadHexColor();
                            result = commands.CircleEncode(commandbyte[0], x0, y0, radius, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "10"://draw rounded rectangle
                            commandbyte[0] = 10;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Ширина", true);
                            y1 = ReadNumber("Высота", true);
                            radius = ReadNumber("Радиус", true);
                            hexcolor = ReadHexColor();
                            result = commands.RoundedRectEncode(commandbyte[0], x0, y0, x1, y1, radius, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "11"://fill rounded rectangle
                            commandbyte[0] = 11;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Ширина", true);
                            y1 = ReadNumber("Высота", true);
                            radius = ReadNumber("Радиус", true);
                            hexcolor = ReadHexColor();
                            result = commands.RoundedRectEncode(commandbyte[0], x0, y0, x1, y1, radius, hexcolor);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "12"://draw text
                            commandbyte[0] = 12;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            hexcolor = ReadHexColor();
                            x1 = ReadNumber("Толщина", true);
                            Console.Write("Введите текст > ");
                            text = Console.ReadLine();
                            y1 = Convert.ToInt16(text.Length);
                            result = commands.TextEncode(commandbyte[0], x0, y0, hexcolor, x1, y1, text);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        case "13"://draw image
                            commandbyte[0] = 13;
                            x0 = ReadNumber("x", false);
                            y0 = ReadNumber("y", false);
                            x1 = ReadNumber("Ширина", true);
                            y1 = ReadNumber("Высота", true);
                            text = ReadPath(); result = commands.ImageEncode(commandbyte[0], x0, y0, x1, y1, text);
                            sender.Send(result, result.Length, endPoint);
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.Yellow; Console.WriteLine("Неизвестная оперция. Попробуйте снова");
                            Console.ResetColor();
                            break;
                    }
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            finally
            {
                sender.Close();
            }
        }
        public static bool IsStringInHex(string text)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(text, @"\A\b[0-9afA-F]+\b\Z");
        }
        private static string ReadHexColor()
        {
            string str;
            while (true)
            {
                Console.Write("Enter RGB565 color > ");
                str = Console.ReadLine();
                if (IsStringInHex(str) && str.Length <= 4)
                {
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Ошибка типа данных!");
                    Console.ResetColor();
                }
            }
            return str;
        }
        private static Int16 ReadNumber(string text, bool onlyPositive = false)
        {
            string str;
            Int16 number;
            while (true)
            {
                Console.Write($"Enter {text} > ");
                str = Console.ReadLine();
                try
                {
                    number = Int16.Parse(str);
                    if (onlyPositive)
                    {
                        if (number < 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Ошибка! Неверные данные! (От 0 до 32767) Попробуйте снова.");Console.ResetColor();
                        }
                        else { break; }
                    }
                    else { break; }
                }
                catch
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Ошибка! Неверные данные! (От -32768 до 32767) Попробуйте снова.");
                    Console.ResetColor();
                }
            }
            return Convert.ToInt16(str);
        }
        private static string ReadPath()
        {
            string str;
            while (true)
            {
                Console.Write("Введите путь > ");
                str = Console.ReadLine();
                if (File.Exists(str) && IsImage(str))
                {
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Error! File does not exist! Try again.");
                    Console.ResetColor();
                }
            }
            return @"" + str;
        }
        public static bool IsImage(string path)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(path, @"^.*\.(jpg|JPG|gif|GIF|png|PNG)$");
        }
        public static void RecieveMessage(UdpClient sender, IPEndPoint endPoint)
        {
            byte[] data = sender.Receive(ref endPoint);
            Console.WriteLine($"Recieved value: {BitConverter.ToInt16(data, 0)}");
        }
    }
}